using UnityEngine;
using UnityEngine.SceneManagement;

public class ObjectManipulator : MonoBehaviour
{
    public GameObject shark; // shark prefab
    [SerializeField] private float value = 0.1f;
    [SerializeField] private Vector3 sizeChangeValue = new Vector3(20f, 20f, 20f);
    [SerializeField] private float rotationValue = 1.5f;
    private Vector3 startposition;
    private Vector3 startScale;
    private Quaternion startRotation;

    public void Start(){
        startposition = new Vector3(shark.transform.position.x, shark.transform.position.y, shark.transform.position.z);
        startScale = new Vector3(shark.transform.localScale.x, shark.transform.localScale.y, shark.transform.localScale.z);
        startRotation = shark.transform.rotation;
    }

    public void MoveRight(){
        shark.transform.position += new Vector3(value, 0, 0);
    }

    public void MoveLeft(){
        shark.transform.position -= new Vector3(value, 0, 0);
    }

    public void MoveUp(){
        shark.transform.position += new Vector3(0, value, 0);
    }

    public void MoveDown(){
        shark.transform.position -= new Vector3(0, value, 0);
    }

    public void ScaleUp(){
        // if scale is more than 10f, then don't scale up
        if(shark.transform.localScale.x > 360 || shark.transform.localScale.y > 360 || shark.transform.localScale.z > 360 ){
            return;
        }
        shark.transform.localScale += sizeChangeValue;
    }

    public void ScaleDown(){
        // if scale is less than 0.1, then don't scale down
        if(shark.transform.localScale.x < 40|| shark.transform.localScale.y < 40 || shark.transform.localScale.z < 40){
            return;
        }
        shark.transform.localScale -= sizeChangeValue;
    }

    public void Reset(){
        shark.transform.position = startposition;
        shark.transform.localScale = startScale;
        shark.transform.rotation = startRotation;
    }

    public void RotateRight(){
        shark.transform.Rotate(0, 0, rotationValue);
    }

    public void RotateLeft(){
        shark.transform.Rotate(0, 0, -rotationValue);
    }

    public void MainMenu(){
        SceneManager.LoadScene("Menu");
    }
}
